public class divisioneZero extends Exception{
	private static final long serialVersionUID = 1L;

    public divisioneZero(){
        super("Un numero non puo' essere divisio per zero");
    }
}