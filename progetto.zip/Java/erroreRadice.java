public class erroreRadice extends Exception{
	private static final long serialVersionUID = 1L;

    public erroreRadice(){
        super("La radice non puo' essere eseguita.");
    }
}