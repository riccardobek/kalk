public class esponenteDiverso extends Exception{
	private static final long serialVersionUID = 1L;

    public esponenteDiverso(){
        super("I due valori non possono essere sommati o sottratti.");
    }
}